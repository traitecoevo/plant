qk_rules <- function() {
  c(15L, 21L, 31L, 41L, 51L, 61L)
}
